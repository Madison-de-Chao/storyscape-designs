import type { DialogueNode } from '@/stores/gameStore';

export const chapter1Nodes: DialogueNode[] = [
  // 一、崩潰的夜晚
  {
    id: 'yi1-chapter-1-1',
    speaker: 'narrator',
    text: '凌晨兩點十七分。',
    nextNodeId: 'yi1-chapter-1-2',
    bgImage: 'room_night', // 深夜辦公桌
  },
  {
    id: 'yi1-chapter-1-2',
    speaker: 'narrator',
    text: '她盯著螢幕，眼睛乾澀得像砂紙。桌上的咖啡早就涼了，杯底沉澱著一層褐色的渣。',
    nextNodeId: 'yi1-chapter-1-3',
  },
  {
    id: 'yi1-chapter-1-3',
    speaker: 'narrator',
    text: '這份報告已經改了五六次。她只記得主管那張嫌棄的臉：「這不是我要的。妳到底有沒有用心？算了，我自己來吧。」',
    nextNodeId: 'yi1-chapter-1-4',
  },
  {
    id: 'yi1-chapter-1-4',
    speaker: 'narrator',
    text: '那個「算了」，像一把鈍刀，慢慢割過她的胸口。',
    nextNodeId: 'yi1-chapter-1-5',
  },

  // 二、從小到大的否定
  {
    id: 'yi1-chapter-1-5',
    speaker: 'narrator',
    text: '她從小就很努力。但現實是——「妳怎麼連這個都做不好？」（母親）、「妳就是不夠聰明。」（老師）、「妳太敏感了。」（前男友）。',
    nextNodeId: 'yi1-chapter-1-6',
  },
  {
    id: 'yi1-chapter-1-6',
    speaker: 'narrator',
    text: '這些聲音在她腦子裡轉成一個結論：我做什麼都不對。',
    nextNodeId: 'yi1-chapter-1-7',
    effect: 'shake',
  },
  {
    id: 'yi1-chapter-1-7',
    speaker: 'narrator',
    text: '她想起一個詞：習得性無助。她就是那隻放棄掙扎的動物。',
    nextNodeId: 'yi1-chapter-1-8',
  },

  // 三、秘密資料夾
  {
    id: 'yi1-chapter-1-8',
    speaker: 'narrator',
    text: '她的手移向滑鼠，打開了另一個隱藏的資料夾。那是她的祕密。一個寫了三年的故事。',
    nextNodeId: 'yi1-chapter-1-9',
  },
  {
    id: 'yi1-chapter-1-9',
    speaker: 'narrator',
    text: '那個故事裡有一個女孩，會魔法，會飛，做什麼都是對的。她寫了將近十萬字，從沒給人看過。因為怕被笑：「都幾歲了還寫這種東西？幼稚。」',
    nextNodeId: 'yi1-chapter-1-10',
  },
  {
    id: 'yi1-chapter-1-10',
    speaker: 'narrator',
    text: '她看著那些檔案：「第一章_覺醒」、「第二章_啟程」……突然覺得很可笑。覺醒？她還是在原地。啟程？她哪裡也沒去。',
    nextNodeId: 'yi1-chapter-1-11',
  },

  // 四、決絕的刪除
  {
    id: 'yi1-chapter-1-11',
    speaker: 'narrator',
    text: '她按下 Ctrl+A。所有檔案變成藍色。她的手指移向 Delete 鍵。',
    nextNodeId: 'yi1-chapter-1-12',
  },
  {
    id: 'yi1-chapter-1-12',
    speaker: 'protagonist',
    text: '刪掉吧。刪掉這個假裝自己還有夢想的笑話。妳都三十歲了，連一份報告都寫不好，憑什麼覺得自己能寫故事？',
    nextNodeId: 'yi1-chapter-1-13',
  },
  {
    id: 'yi1-chapter-1-13',
    speaker: 'narrator',
    text: '她按下了 Delete。檔案消失了。她打開資源回收筒，點擊右鍵：「清空資源回收筒」。',
    effect: 'shake',
    nextNodeId: 'yi1-chapter-1-14',
  },

  // 五、異常的對話框
  {
    id: 'yi1-chapter-1-14',
    speaker: 'narrator',
    text: '一個對話框彈了出來。但上面寫的不是「確定要刪除嗎？」，而是——',
    nextNodeId: 'yi1-chapter-1-15',
  },
{
    id: 'yi1-chapter-1-15',
    speaker: 'system',
    speakerName: 'SYSTEM',
    text: '「你確定要丟棄這些嗎？它們還沒完成。」',
    effect: 'glitch', // 👈 這裡！加上故障特效
    emotionSFX: 'digital_break', 
    nextNodeId: 'yi1-chapter-1-16',
  },
  {
    id: 'yi1-chapter-1-16',
    speaker: 'narrator',
    text: '她愣住了。不是「無法復原」，而是「它們還沒完成」。好像有人在跟她說話。',
    nextNodeId: 'yi1-chapter-1-choice',
  },

  // 六、最後的選擇
  {
    id: 'yi1-chapter-1-choice',
    speaker: 'narrator',
    text: '腦子裡有個聲音說：刪掉吧，妳沒有用。但另一個微弱的聲音說：等一下，再想一下……',
    choices: [
      { 
        id: 'ch1-confirm', 
        text: '按下「確定」', 
        nextNodeId: 'yi1-chapter-1-17',
        arcChange: 0,
        shadowChange: 5 
      },
      // 這裡原著中她其實是按下了確定，所以這是單行道，或者無論選什麼結果都一樣
    ],
  },
  {
    id: 'yi1-chapter-1-17',
    speaker: 'narrator',
    text: '她閉上眼，看見了一種模糊的感覺，像是有人在等她。然後，她按下了「確定」。',
    nextNodeId: 'yi1-chapter-1-18',
  },
  
  // 七、穿越
  {
    id: 'yi1-chapter-1-18',
    speaker: 'narrator',
    text: '螢幕突然變白。不是當機的白，是發光的白。那光把她整個人包住。',
    bgImage: 'white_screen', // 全白畫面
    effect: 'flash',
    nextNodeId: 'yi1-chapter-1-19',
  },
  {
    id: 'yi1-chapter-1-19',
    speaker: 'narrator',
    text: '世界在旋轉。那個房間、那杯涼掉的咖啡離她越來越遠。一切歸於寂靜。',
    nextNodeId: 'yi1-chapter-1-20',
  },
  {
    id: 'yi1-chapter-1-20',
    speaker: 'narrator',
    text: '她最後聽見的，是一個聲音：「你來了。我們等你很久了。」',
    nextNodeId: 'yi1-chapter-2-1', // 🔗 連接到第二章（渡口）
    effect: 'fade-out',
  },
];
